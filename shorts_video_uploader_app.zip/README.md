# Shorts Video Uploader App

Flutter app to upload & view short videos.
