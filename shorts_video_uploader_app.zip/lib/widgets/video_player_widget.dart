// Video player widget
